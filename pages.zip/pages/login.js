import AdminLogin from './Admin/AdminLogin'; // Adjust the path based on your file structure

const Login = () => {
  return <AdminLogin />;
};

export default Login;
